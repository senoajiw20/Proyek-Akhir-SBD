--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kategori; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.kategori AS ENUM (
    'kategori1',
    'kategori2',
    'kategori3'
);


ALTER TYPE public.kategori OWNER TO postgres;

--
-- Name: metode_pemb; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.metode_pemb AS ENUM (
    'Transfer',
    'COD'
);


ALTER TYPE public.metode_pemb OWNER TO postgres;

--
-- Name: metode_pembayaran; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.metode_pembayaran AS ENUM (
    'Transfer',
    'COD'
);


ALTER TYPE public.metode_pembayaran OWNER TO postgres;

--
-- Name: status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status AS ENUM (
    'Diproses',
    'Dikirim',
    'Sampai'
);


ALTER TYPE public.status OWNER TO postgres;

--
-- Name: status_pemb; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_pemb AS ENUM (
    'Belum dibayar',
    'Telah dibayar'
);


ALTER TYPE public.status_pemb OWNER TO postgres;

--
-- Name: status_pembayaran; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status_pembayaran AS ENUM (
    'Belum dibayar',
    'Telah dibayar'
);


ALTER TYPE public.status_pembayaran OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id bigint NOT NULL,
    nama character varying(30) NOT NULL,
    email character varying(30) NOT NULL,
    no_hp character varying(15) NOT NULL,
    password character varying(30)
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_customer_id_seq OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    email character varying(30),
    jumlah integer,
    alamat character varying(150),
    subtotal integer
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_order_id_seq OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- Name: orders_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_product_id_seq OWNER TO postgres;

--
-- Name: orders_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_product_id_seq OWNED BY public.orders.product_id;


--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pembayaran (
    no_pembayaran integer,
    order_id bigint NOT NULL,
    metode_pembayaran public.metode_pemb,
    status_pembayaran public.status_pemb
);


ALTER TABLE public.pembayaran OWNER TO postgres;

--
-- Name: pembayaran_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pembayaran_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pembayaran_order_id_seq OWNER TO postgres;

--
-- Name: pembayaran_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pembayaran_order_id_seq OWNED BY public.pembayaran.order_id;


--
-- Name: pengiriman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pengiriman (
    no_pengiriman integer,
    order_id integer,
    alamat character varying(150),
    status_pengiriman public.status
);


ALTER TABLE public.pengiriman OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id bigint NOT NULL,
    nama_produk character varying(50) NOT NULL,
    deskripsi character varying(300) NOT NULL,
    kategori public.kategori,
    harga integer
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product.product_id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id bigint NOT NULL,
    nama_produk character varying(50) NOT NULL,
    deskripsi character varying(300) NOT NULL,
    kategori character varying(30),
    harga integer,
    image character varying(100)
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: orders product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN product_id SET DEFAULT nextval('public.orders_product_id_seq'::regclass);


--
-- Name: pembayaran order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pembayaran ALTER COLUMN order_id SET DEFAULT nextval('public.pembayaran_order_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN product_id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, nama, email, no_hp, password) FROM stdin;
1	Seno Aji	senoajiw20@gmail.com	082122138586	pass
2	Michael De Santa	michaeldesanta@gmail.com	081155551111	passcode
6	Jidofajoa	dflksllkasd	0982388982	lkdflksdlkj
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, product_id, email, jumlah, alamat, subtotal) FROM stdin;
1	11	michaeldesanta@gmail.com	2	Beverly Hilss	\N
2	11	senoajiw20@gmail.com	3	Desa	\N
3	11	senoajiw20@gmail.com	4	Tes	\N
4	1	\N	\N	\N	73128
5	11	senoajiw20@gmail.com	2	Tos	\N
6	11	senoajiw20@gmail.com	3	Tis	54846
7	1	senoajiw20@gmail.com	1	Desa	549000
8	6	senoajiw20@gmail.com	1	Jakarta	249000
\.


--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pembayaran (no_pembayaran, order_id, metode_pembayaran, status_pembayaran) FROM stdin;
\.


--
-- Data for Name: pengiriman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pengiriman (no_pengiriman, order_id, alamat, status_pengiriman) FROM stdin;
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, nama_produk, deskripsi, kategori, harga) FROM stdin;
1	bunga 1	jfalkadsflkfads	kategori1	15000
2	bunga 1	jaljkdskajk	kategori1	15000
3	bunga 1	jaljkdskajk	kategori1	15000
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, nama_produk, deskripsi, kategori, harga, image) FROM stdin;
1	Joy of Yellow Tulip Arrangement	Yellow Tulips In A Vase	florist collection	549000	joy_of_yellow_tulip_arrangement.jpg
2	Celestial Purplish Arrangement	Combination of Purple Roses, Pink Roses, Orchids, Hydrangea, Calla Lilly, Casa Blanca and Palm Leaf	florist collection	399000	calaestial_purplish_arrangement.jpg
4	Yellow and White Flower Arrangement	NULL	florist collection	399000	yellow_and_white_flower_arrangement.jpg
5	Luxury White Arrangement	NULL	florist collection	399000	luxury_white_arrangement.jpg
6	Red Rose Flat Table Arrangement	Combination of Red Roses, chrysanthemum, Red Orchids, and Wax.	long and low centerpiece	249000	red_rose_flat_table_arrangement.jpg
\.


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 6, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 8, true);


--
-- Name: orders_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_product_id_seq', 1, true);


--
-- Name: pembayaran_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pembayaran_order_id_seq', 1, false);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_id_seq', 3, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_product_id_seq', 6, true);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- PostgreSQL database dump complete
--

