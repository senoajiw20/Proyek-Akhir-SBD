1-pertama-tama untuk meload database dapat dilakukan dengna menggunakan file pgdump tes.sql
2-untuk dapat terhubung dengan website dapat dilakukan dengan menjalankan command node index.js pada terminal
3-akses ke website dapat dilakukan dengan mengakses localhost:5500
4-pada website tersebut, untuk mendaftarkan customer dapat dilakukan dengan mengakses menu register melalui tombol register atau melalui url localhost:5500/register
5-pemesanan dapat dilakukan untuk tiap itemnya dengan mengakses cek produk pada tiap item lalu menginput email, jumlah yang ingin di pesan dan alamat pengiriman
6-setelah melakukan pemesanan, maka pembeli akan diarahkan ke menu order list yang menampilkan list dari pemesanan yang dilakukan oleh seluruh customer