const express = require('express');
const app = express();
const fileUpload = require('express-fileupload');
const { Client } = require('pg');
const { response } = require('express');
const fs = require('fs');
const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'proyek',
    password: '',
    port: 5432,
    multipleStatements:true
});

client.connect((err) =>{
    if (err) {
        console.error(err);
        return;
    }
    console.log('Database Connected');
});
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded({ extended: false })); 
app.use(fileUpload());

//laman utama
app.get('/', function(req, res) {
    res.render('index', {
      });
});

app.get('/register', function(req, res) {
    res.render('register');
});

app.get('/products', function(req, res) {
    res.render('product');
});

app.get('/', function(req, res) {
    res.render('index', {
      });
});

app.get('/', function(req, res) {
    const query = `SELECT * FROM products`;
    client.query(query , [], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
        res.render('index', {
            model: results.rows
          });
    });
});

//laman untuk menambahkan produk (sebagai admin)
app.get('/admin', function(req, res) {
    client.query("SELECT * FROM products", [], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
        res.render('addproduct', {
            model: results.rows
          });
    });
});

//menambahkan produk
app.post("/addproduct", (req, res) => {
    // if (!req.files || Object.keys(req.files).length === 0) {
    //     return res.status(400).send('No files were uploaded.');
    // }
    // let uploadedFile = req.files.gambar;
    // let image_name = uploadedFile.name;
    // //upload image file to directory public/images/
    // uploadedFile.mv(`gambar/${image_name}`, (err ) => {
    //     if (err) {
    //         return res.status(500).send(err);
    //     }
    // });

    const query = `INSERT INTO products(nama_produk, deskripsi, kategori, harga, image) VALUES ($1, $2, $3, $4, %5)`;
    const produk = [req.body.nama_produk, req.body.deskripsi, req.body.kategori, req.body.harga, req.body.image];
    client.query(query, produk, (err, result) => {
    if (err) {
        console.error(err);
    return;
    }
    });
    res.redirect("/");
});


//menambahkan customer
app.post("/addcustomer", (req, res) => {
    const query = `INSERT INTO customers(nama, email, no_hp, password) VALUES ($1, $2, $3, $4)`;
    const produk = [req.body.nama, req.body.email, req.body.no_hp, req.body.password];
    client.query(query, produk, (err, result) => {
    if (err) {
        console.error(err);
    return;
    }
    });
    res.redirect("/");
});

//menambahkan prduk
app.post("/addorder/:id", (req, res) => {
    const query = `INSERT INTO orders (product_id, email, jumlah, alamat, subtotal) VALUES ($1, $2, $3, $4, (SELECT harga FROM products WHERE product_id = $1)*$3)`;
    const produk = [req.params.id, req.body.email, req.body.jumlah, req.body.alamat];
    client.query(query, produk, (err, result) => {
    if (err) {
        console.error(err);
    return;
    }
    });
    res.redirect("/orderlist");
});


app.get('/orderlist', function(req, res) {
    client.query("SELECT * FROM orders", [], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
        res.render('orderlist', {
            model: results.rows
          });
    });
});

app.get('/products/:id', async (req, res) => {
    const id = req.params.id;
    console.log(req.params.id);
    client.query("SELECT * FROM products WHERE product_id = $1", [id], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
        res.render('product', {
            model: results.rows[0]
          });
    });
})

app.get('/customer/:id', async (req, res) => {
    const id = req.params.id;
    client.query("SELECT * FROM customers WHERE customer_id = $", [id], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
        res.render('customer', {
            model: results.rows[0]
          });
    });
})

app.post("/delete/:id", (req, res) => {
    const id = req.params.id;
    const query = `DELETE FROM products WHERE product_id = $1`;
    client.query(query , [id], (err, results) => {
        if (err) {
            console.error(err);
            return;
        }
    }); 
    res.redirect("/");
 });

app.listen(5500,()=>{
    console.log('tes');
})